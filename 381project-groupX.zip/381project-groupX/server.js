// server.js

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cookieSession = require('cookie-session');
const methodOverride = require('method-override');
const path = require('path');
const dotenv = require('dotenv');
const flash = require('connect-flash');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const fs = require('fs');
const winston = require('winston');
const expressLayouts = require('express-ejs-layouts'); // 导入 express-ejs-layouts

// Load environment variables from .env file
dotenv.config();

// Initialize Express app
const app = express();

// Setup logging with morgan and winston
const logDirectory = path.join(__dirname, 'logs');

// Ensure log directory exists
if (!fs.existsSync(logDirectory)) {
    fs.mkdirSync(logDirectory);
}

// Create a write stream for morgan
const accessLogStream = fs.createWriteStream(path.join(logDirectory, 'access.log'), { flags: 'a' });

// Setup morgan middleware for HTTP request logging
app.use(morgan('combined', { stream: accessLogStream }));

// Setup winston logger for error logging
const logger = winston.createLogger({
    level: 'error',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
    ),
    transports: [
        new winston.transports.File({ filename: path.join(logDirectory, 'error.log') }),
    ],
});

// Connect to MongoDB
const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/381project';
mongoose.connect(mongoURI)
    .then(() => {
        console.log('Connected to MongoDB.');
    })
    .catch((err) => {
        console.error('MongoDB connection error:', err);
        logger.error('MongoDB connection error:', err);
    });

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Configure method-override for PUT and DELETE methods
app.use(methodOverride('_method'));

// Configure helmet for enhanced security
app.use(helmet());

// Configure rate limiting to prevent brute-force attacks
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Limit each IP to 100 requests per windowMs
    message: 'Too many requests from this IP, please try again after 15 minutes',
});
app.use(limiter);

// Configure cookie-session
app.use(cookieSession({
    name: 'session',
    keys: [process.env.SESSION_KEY1, process.env.SESSION_KEY2],
    maxAge: 24 * 60 * 60 * 1000, // 24 hours
    secure: process.env.NODE_ENV === 'production', // Use secure cookies in production
    httpOnly: true, // Prevents client-side JavaScript from accessing the cookie
}));

// Configure flash messages
app.use(flash());

// Configure express-ejs-layouts
app.use(expressLayouts);
app.set('layout', 'layout'); // 设置默认布局文件为 views/layout.ejs

// Set EJS as templating engine
app.set('view engine', 'ejs');

// Serve static files from 'public' folder
app.use(express.static(path.join(__dirname, 'public')));

// Global variables middleware for flash messages and user session
app.use((req, res, next) => {
    res.locals.success_msg = req.flash('success_msg');
    res.locals.error_msg = req.flash('error_msg');
    res.locals.error = req.flash('error');
    res.locals.user = req.session.userId;
    next();
});

// Import Routes
const authRoutes = require('./routes/auth');
const crudRoutes = require('./routes/crud');
const apiRoutes = require('./routes/api');

// Use Routes
app.use('/', authRoutes);
app.use('/crud', crudRoutes);
app.use('/api', apiRoutes);

// Home Route
app.get('/', (req, res) => {
    res.redirect('/login');
});

// 404 Handler
app.use((req, res, next) => {
    res.status(404).render('404', { title: '404 Not Found' });
});

// Error Handler
app.use((err, req, res, next) => {
    console.error(err.stack);
    logger.error('Server Error:', err);
    res.status(500).render('500', { title: '500 Server Error' });
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
